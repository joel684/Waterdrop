# WaterBoost

Tiny Android RAM monitor. A water-filled circle shows how much RAM is used; "Clean now" (or auto mode)
asks Android to stop background processes of your apps.

* **Clean now** - stops background processes of launchable user apps, reports MB actually freed.
* **Auto clean** - foreground service checks every 30 s; cleans when free RAM < limit (cooldown adapts).
* **Protected apps** - apps that are never touched (launcher, keyboard, SMS, dialer are always protected).
* **Shizuku (optional)** - measures each app's real memory, closes only the heaviest ones and stops once
  enough is freed. Also shows a "Top memory apps" list. Falls back to normal mode if Shizuku isn't running.
* **Launcher** - WaterBoost can be your home screen: Ghibli-style painted sea (horizon height = RAM used; sky, sun, clouds and waves shift blue ->
  sunset gold -> rose red as RAM runs low, livelier waves when memory is tight, stays level when you tilt the phone), clock,
  dock, searchable app drawer, long-press app menu. Falls back to a 2D wave if the GPU can't run the shader.
* **Deep clean (Shizuku)** - force-stops chosen apps (or all non-protected ones) and clears every app's cache
  (`pm trim-caches`). Auto mode runs when you reach the home screen and RAM is low. Never touches app data.
* **Realme / OPPO tuning** (tested target: Realme Narzo 50A Prime, 4 GB, Android 11, Realme UI) - default
  limit scales with RAM, Google/Realme system helpers are never closed, auto mode pauses with the screen
  off, "Keep running in background" opens Realme UI's auto-start screen. Device code lives in Device.kt.
* Build: push to GitHub, run the "Build APK" workflow, download the debug APK artifact.

## 2.1 fixes (auto mode stopping + lag)
* Back-off no longer climbs to 15 min (max 3 min) and resets when the screen turns on.
* A stuck clean/shell call can no longer block cleaning forever (timeouts + busy watchdog).
* App list is cached, no more loading every app label on each clean.
* Kill batches capped to the 12 heaviest apps; auto deep clean throttled to once per 5 min.
* Service loop survives errors, restarts via an alarm if Realme UI kills it, survives swiping from recents.
* Launcher water renders at 1/3 resolution and ~22 fps.

## 2.2 Ghibli water
* New cheap toon shader: pastel sky, sun, drifting clouds, five flat wave layers with foam lines and sparkles.
* Whole scene palette follows RAM: calm blue -> golden sunset -> rose-red dusk.
* Rendering pauses while the app drawer covers the screen.

## 2.3 Built-in Control Panel
* The launcher now has its own Control Panel tile: always first in the app drawer and permanently first in the dock
  (a round water-drop badge). Tap it to open the settings/cleaner screen; long-press for "Open control panel" / "Clean RAM now".
* The separate WaterBoost entry no longer shows up as a normal app in the drawer. Dock holds the Control Panel plus up to 4 apps.

## 2.4 Shizuku connection card
* Control Panel has a "SHIZUKU CONNECTION" card: live status (connected / permission needed / not running / not installed),
  a hint for the next step, and one button that does it (get Shizuku, open it to start, ask permission, or connect and test).
* Updates instantly when Shizuku starts or stops.

## 2.5 Tuned for realme narzo 50A Prime (Unisoc T612, Mali-G57, 4 GB, 1080x2408)
* Water renders at ~360 px wide with no depth buffer, and steps down by itself (30 -> 24 -> 20 fps, lower resolution)
  if the measured frame rate falls behind. Battery saver caps it at 20 fps and halves the auto-clean check rate.
* Cleaning and app loading run at background thread priority so they never fight the UI on the A55 cores.
* Default RAM trigger is 22% of total (~800 MB). Shizuku itself is never closed.
* Control Panel shows chip and RAM, and has a "Battery: allow unrestricted" button (Realme UI kills optimised apps).
* Android 12+ refusing a background foreground-start no longer crashes the service.
* Build now makes an optimised, shrunk release APK next to the debug one. If the release APK ever misbehaves,
  install the debug APK from the same artifact.
