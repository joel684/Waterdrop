# Shizuku starts ShellService by class name and talks to it through the AIDL stubs: none of these may be renamed.
-keep class com.waterboost.app.ShellService { *; }
-keep class com.waterboost.app.IShell { *; }
-keep class com.waterboost.app.IShell$Stub { *; }
-keep class com.waterboost.app.IShell$Stub$Proxy { *; }
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }
-dontwarn rikka.**
-dontwarn moe.shizuku.**
