package com.waterboost.app

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.sqrt

/**
 * Studio-Ghibli-style sea drawn by one very cheap fragment shader: pastel sky, a soft sun, puffy drifting
 * clouds and five layers of flat-coloured waves with white foam lines on the crests. The horizon height is
 * the RAM level, and the whole scene's palette changes with it: calm blue day -> golden sunset -> rose-red dusk.
 * If the shader fails to compile on some GPU, [onFail] is called and the launcher switches to a 2D wave.
 */
class WaterRenderer(private val onFail: () -> Unit) : GLSurfaceView.Renderer {
    @Volatile var used = 0.5f      // RAM used, 0..1
    @Volatile var upX = 0f         // direction of "up" on screen from the accelerometer (water stays level)
    @Volatile var upY = 1f

    // Average time between frames, so the launcher can lower quality by itself if this GPU can't keep up.
    private var lastNs = 0L
    private var frames = 0
    private var avgMs = 0f
    val measuredMs: Float get() = if (frames >= 20) avgMs else 0f
    fun resetStats() { lastNs = 0L; frames = 0; avgMs = 0f }

    private var prog = 0
    private var aPos = 0
    private var uRes = 0; private var uTime = 0; private var uLevel = 0; private var uUp = 0
    private var uDeep = 0; private var uShallow = 0; private var uChop = 0
    private var uSkyTop = 0; private var uSkyLow = 0
    private var w = 1f
    private var h = 1f
    private var level = 0.5f
    private var sx = 0f
    private var sy = 1f
    private val t0 = System.nanoTime()
    private val deep = FloatArray(3)
    private val shallow = FloatArray(3)
    private val skyTop = FloatArray(3)
    private val skyLow = FloatArray(3)
    private val tmp = FloatArray(3)
    private val quad = ByteBuffer.allocateDirect(32).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); position(0)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        prog = link(VERTEX, FRAGMENT)
        if (prog == 0) { onFail(); return }
        aPos = GLES20.glGetAttribLocation(prog, "aPos")
        uRes = GLES20.glGetUniformLocation(prog, "uRes")
        uTime = GLES20.glGetUniformLocation(prog, "uTime")
        uLevel = GLES20.glGetUniformLocation(prog, "uLevel")
        uUp = GLES20.glGetUniformLocation(prog, "uUp")
        uDeep = GLES20.glGetUniformLocation(prog, "uDeep")
        uShallow = GLES20.glGetUniformLocation(prog, "uShallow")
        uSkyTop = GLES20.glGetUniformLocation(prog, "uSkyTop")
        uSkyLow = GLES20.glGetUniformLocation(prog, "uSkyLow")
        uChop = GLES20.glGetUniformLocation(prog, "uChop")
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        w = width.toFloat(); h = height.toFloat()
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        if (lastNs != 0L) {
            val d = (now - lastNs) / 1_000_000f
            if (d < 500f) { frames++; avgMs = if (frames <= 1) d else avgMs * 0.9f + d * 0.1f }   // ignore pauses
        }
        lastNs = now
        if (prog == 0) {
            GLES20.glClearColor(0.04f, 0.07f, 0.13f, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            return
        }
        level += (used.coerceIn(0f, 1f) - level) * 0.05f
        sx += (upX - sx) * 0.15f
        sy += (upY - sy) * 0.15f
        val m = sqrt(sx * sx + sy * sy).let { if (it < 0.01f) 1f else it }

        // Calm blue while there is plenty of RAM, golden sunset getting low, rose-red dusk when almost out.
        val t1 = clamp01((level - 0.65f) / 0.15f)
        val t2 = clamp01((level - 0.80f) / 0.12f)
        palette(BLUE_D, AMBER_D, RED_D, t1, t2, deep)
        palette(BLUE_S, AMBER_S, RED_S, t1, t2, shallow)
        palette(BLUE_ST, AMBER_ST, RED_ST, t1, t2, skyTop)
        palette(BLUE_SL, AMBER_SL, RED_SL, t1, t2, skyLow)

        GLES20.glUseProgram(prog)
        GLES20.glUniform2f(uRes, w, h)
        GLES20.glUniform1f(uTime, (((System.nanoTime() - t0) / 1_000_000_000.0) % 3600.0).toFloat())
        GLES20.glUniform1f(uLevel, level.coerceIn(0.12f, 0.97f))
        GLES20.glUniform2f(uUp, sx / m, sy / m)
        GLES20.glUniform3f(uDeep, deep[0], deep[1], deep[2])
        GLES20.glUniform3f(uShallow, shallow[0], shallow[1], shallow[2])
        GLES20.glUniform3f(uSkyTop, skyTop[0], skyTop[1], skyTop[2])
        GLES20.glUniform3f(uSkyLow, skyLow[0], skyLow[1], skyLow[2])
        GLES20.glUniform1f(uChop, 0.7f + 0.8f * level)   // livelier waves when RAM is tight
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, quad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun clamp01(x: Float) = if (x < 0f) 0f else if (x > 1f) 1f else x

    private fun mix3(a: FloatArray, b: FloatArray, t: Float, out: FloatArray) {
        for (i in 0..2) out[i] = a[i] + (b[i] - a[i]) * t
    }

    private fun palette(a: FloatArray, b: FloatArray, c: FloatArray, t1: Float, t2: Float, out: FloatArray) {
        mix3(a, b, t1, tmp); mix3(tmp, c, t2, out)
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) { GLES20.glDeleteShader(s); return 0 }
        return s
    }

    private fun link(vs: String, fs: String): Int {
        val v = compile(GLES20.GL_VERTEX_SHADER, vs)
        val f = compile(GLES20.GL_FRAGMENT_SHADER, fs)
        if (v == 0 || f == 0) return 0
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, v)
        GLES20.glAttachShader(p, f)
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) { GLES20.glDeleteProgram(p); return 0 }
        return p
    }

    companion object {
        // water far layers (shallow) / near layers (deep), sky top / sky near the horizon
        private val BLUE_D = floatArrayOf(0.10f, 0.45f, 0.62f)
        private val BLUE_S = floatArrayOf(0.38f, 0.80f, 0.83f)
        private val BLUE_ST = floatArrayOf(0.45f, 0.72f, 0.93f)
        private val BLUE_SL = floatArrayOf(0.88f, 0.96f, 0.98f)

        private val AMBER_D = floatArrayOf(0.62f, 0.38f, 0.24f)
        private val AMBER_S = floatArrayOf(0.98f, 0.76f, 0.40f)
        private val AMBER_ST = floatArrayOf(0.97f, 0.68f, 0.45f)
        private val AMBER_SL = floatArrayOf(1.00f, 0.91f, 0.68f)

        private val RED_D = floatArrayOf(0.50f, 0.14f, 0.22f)
        private val RED_S = floatArrayOf(0.93f, 0.42f, 0.38f)
        private val RED_ST = floatArrayOf(0.62f, 0.24f, 0.38f)
        private val RED_SL = floatArrayOf(0.98f, 0.62f, 0.52f)

        private const val VERTEX = "attribute vec2 aPos;\nvoid main() { gl_Position = vec4(aPos, 0.0, 1.0); }\n"

        private val FRAGMENT = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform vec2 uRes;
uniform float uTime;
uniform float uLevel;
uniform vec2 uUp;
uniform vec3 uDeep;
uniform vec3 uShallow;
uniform vec3 uSkyTop;
uniform vec3 uSkyLow;
uniform float uChop;

// Signed distance to a puffy cloud made of four overlapping circles (centre cx,cy, size s).
float cloud(vec2 p, float cx, float cy, float s) {
    vec2 q = (p - vec2(cx, cy)) / s;
    q.y *= 1.5;
    float d = length(q) - 0.28;
    d = min(d, length(q - vec2(-0.30, -0.05)) - 0.20);
    d = min(d, length(q - vec2(0.32, -0.06)) - 0.22);
    d = min(d, length(q - vec2(0.02, 0.13)) - 0.20);
    return d * s;
}

void main() {
    float aspect = uRes.x / uRes.y;
    vec2 c = (gl_FragCoord.xy / uRes - 0.5) * vec2(aspect, 1.0);
    // Rotate the view so the sea stays level when the phone is tilted.
    float x = c.x * uUp.y - c.y * uUp.x;
    float y = c.x * uUp.x + c.y * uUp.y;
    float hz = uLevel - 0.5;
    float t = uTime;
    float aa = 1.2 / uRes.y;

    // ---- sky: pastel gradient, soft sun, drifting clouds
    vec3 col = mix(uSkyLow, uSkyTop, smoothstep(0.0, 0.85, (y - hz) * 1.3));
    vec2 sp = vec2(0.10, hz + 0.20);
    float sd = length(vec2(x, y) - sp);
    col += uSkyLow * exp(-sd * 6.0) * 0.30;
    col = mix(col, vec3(1.0, 0.97, 0.84), (1.0 - smoothstep(0.066, 0.072, sd)));

    vec3 shade = mix(uSkyLow, vec3(0.72, 0.78, 0.92), 0.55);
    float cx = mod(x + t * 0.008 + 0.30, 1.0) - 0.5;
    float cy = hz + 0.30;
    float d = cloud(vec2(cx, y), 0.0, cy, 0.24);
    col = mix(col, mix(shade, vec3(1.0), smoothstep(-0.10, 0.08, (y - cy) / 0.24)), (1.0 - smoothstep(0.0, aa * 2.0, d)));

    cx = mod(x + t * 0.005 + 0.72, 0.9) - 0.45;
    cy = hz + 0.44;
    d = cloud(vec2(cx, y), 0.0, cy, 0.16);
    col = mix(col, mix(shade, vec3(1.0), smoothstep(-0.10, 0.08, (y - cy) / 0.16)), (1.0 - smoothstep(0.0, aa * 2.0, d)));

    cx = mod(x * 0.9 + t * 0.012 + 0.12, 0.8) - 0.4;
    cy = hz + 0.15;
    d = cloud(vec2(cx, y), 0.0, cy, 0.12);
    col = mix(col, mix(shade, vec3(1.0), smoothstep(-0.10, 0.08, (y - cy) / 0.12)), (1.0 - smoothstep(0.0, aa * 2.0, d)));

    // ---- sea: five flat wave layers painted far -> near, each with a foam line on its crest
    vec3 foam = mix(vec3(1.0), uSkyLow, 0.18);
    float gap = clamp(uLevel * 0.16, 0.025, 0.09);
    for (int k = 0; k < 5; k++) {
        float fk = float(k);
        float dir = (mod(fk, 2.0) < 1.0) ? 1.0 : -1.0;
        float amp = (0.007 + 0.005 * fk) * uChop;
        float f = 26.0 - fk * 3.0;
        float sp2 = 0.6 + 0.22 * fk;
        float edge = hz - 0.012 - fk * gap
            + amp * sin(x * f + t * sp2 * dir + fk * 2.0)
            + amp * 0.5 * sin(x * f * 2.3 - t * sp2 * 0.7 + fk * 1.7);
        float m = 1.0 - smoothstep(edge - aa, edge + aa, y);
        vec3 lc = mix(uShallow, uDeep, fk / 4.0);
        lc = mix(lc, uSkyLow, 0.25 * (1.0 - fk / 4.0));          // far layers fade into the haze
        lc = mix(lc, lc * 0.80, clamp((edge - y) * 6.0, 0.0, 1.0)); // each band gets a little darker downwards
        col = mix(col, lc, m);
        float fb = m * smoothstep(edge - 0.011, edge - 0.011 + aa * 2.0, y);
        col = mix(col, foam, fb * (0.55 + 0.1 * fk));
        float g = step(0.985, sin(x * (41.0 + fk * 7.0) + t * (1.1 + fk * 0.2)) * sin(y * 90.0 + fk * 3.0 - t * 0.4));
        col += vec3(0.5) * g * m * step(y, edge - 0.02) * step(1.5, fk);   // tiny sparkles on the near waves
    }
    gl_FragColor = vec4(col, 1.0);
}
""".trimIndent()
    }
}
